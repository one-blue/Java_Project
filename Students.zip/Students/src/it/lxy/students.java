package it.lxy;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
public class students extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JScrollPane scrollPane; 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					students frame = new students();
					frame.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	

	public students() {
		setTitle("ѧ����Ϣ����ϵͳ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 150, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
        
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.NORTH);
		
		JButton btnadd = new JButton("����");
		panel_1.add(btnadd);
		btnadd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null,new add().getContentPane());
				
}
		});
		
		
		JButton btndel = new JButton("ɾ��");
		btndel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,new del().getContentPane());
			
			}
			
			
		});
		
		panel_1.add(btndel);
		
		JButton btnupd = new JButton("�޸�");
		panel_1.add(btnupd);
		btnupd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null,new upd().getContentPane());
			}
		});
		JButton btnlok = new JButton("��ѯ");
		panel_1.add(btnlok);
		
		
		btnlok.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(null,new chx().getContentPane());
			}
		});
		JButton btnNewButton = new JButton("��ѯȫ��");
		panel_1.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				xcq();
			
			}
		});
		
		
	
	}
	public void xcq(){
		Vector<String> col = new Vector<String>();
		col.add("name");
		col.add("seg");
		col.add("id");
		Vector<Vector<String>> row = new Vector<Vector<String>>();
		//DriverManager.registerDriver(new Driver()); // ���ע���ע������
		//1.ע����������������ֽ����ļ�
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
		
		//2.��ȡ���ݿ����Ӷ���
		//�������ݿ�               ��������ӵ��Ǳ������˿ں���3306����������� ("jdbc:mysql:///test", "root", "root"��     ��������������    "jdbc:mysql://ip��ַ:�˿ں�/���ݿ���","�û���","����"
	Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/class", "root", "root");


	 //3.��ȡSQL����ִ���߶��� 
	 PreparedStatement pst =conn.prepareStatement("select * from students_info");
	 //4.ִ��SQL���
	  ResultSet resultSet =  pst.executeQuery();
	  //���������
	 while(resultSet.next()){     //�����ݷ���true,���򷵻�false
		Vector<String> hang =new Vector<String>();
	hang.add(resultSet.getString(1));
	hang.add(resultSet.getString(2));
	hang.add(resultSet.getString(3));
	row.add(hang);
	 }
		
	 //6.�ر����ͷ���Դ
	 conn.close();//���Ӷ���ر�
	 pst.close();//�ر�ִ���߶���
	 resultSet.close();//�رս��������
	 JTable jt= new JTable(row,col);
	 scrollPane = new JScrollPane(jt);
	
	 contentPane.add(scrollPane, BorderLayout.CENTER);
	
	 contentPane.updateUI();
	 contentPane.repaint();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}
