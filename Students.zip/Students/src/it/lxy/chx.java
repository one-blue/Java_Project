package it.lxy;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;

public class chx extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					chx frame = new chx();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public chx() {
		setTitle("��ѯ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("������Ҫ��ѯ��ѧ��");
		contentPane.add(lblNewLabel, BorderLayout.NORTH);
		
		textField = new JTextField();
		contentPane.add(textField, BorderLayout.WEST);
		textField.setColumns(10);
		
		btnNewButton_1 = new JButton("��ѯ");
		contentPane.add(btnNewButton_1, BorderLayout.SOUTH);
		
		lblNewLabel_1 = new JLabel();
		contentPane.add(lblNewLabel_1, BorderLayout.EAST);
		
		Vector<String> col=new Vector<String>();
		Vector<Vector<String>> row = new Vector<Vector<String>>();
		col.add("name");
		col.add("seg");
		col.add("id");
		btnNewButton_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/class","root","root");
					String ID=textField.getText();
					java.sql.PreparedStatement pst=conn.prepareStatement("SELECT * FROM students_info WHERE id= ?");
				pst.setObject(1, ID);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
				
					Vector<String> hang=new Vector<String>();
					hang.add(rs.getString("name"));
					hang.add(rs.getString("seg"));
					hang.add(rs.getString("id"));
					row.add(hang);
					lblNewLabel_1.setText(rs.getString("name")+rs.getString("seg")+rs.getString("id"));
				}
			
	
				 pst.close();
				 conn.close();
		table = new JTable(row,col);
		table.setVisible(true);
		contentPane.add(table, BorderLayout.CENTER);
		
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
});
}

}
