package it.lxy;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;

public class del extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					del frame = new del();
					frame.setVisible(true);
					 
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public del() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		JLabel label = new JLabel("������ѧ��ɾ����Ӧ����Ϣ��");
		contentPane.add(label, BorderLayout.NORTH);
		JRadioButton radioButton = new JRadioButton("ѧ��");
		JPanel panel = new JPanel();
		panel.add(radioButton);
		contentPane.add(panel, BorderLayout.WEST);
		textField = new JTextField();
		contentPane.add(textField, BorderLayout.CENTER);
		textField.setColumns(10);
		JButton btnNewButton = new JButton("ȷ��ɾ��");
		contentPane.add(btnNewButton, BorderLayout.SOUTH);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
					//ע������
					try {
						Class.forName("com.mysql.jdbc.Driver");
				
					//��ȡ���ݿ�����
					
						Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/class", "root", "root");
						 String ID=textField.getText();
						 java.sql.PreparedStatement pst=conn.prepareStatement("DELETE FROM students_info WHERE id=?");
						 pst.setObject(1, ID);
						 pst.executeUpdate();
						 pst.close();
						 conn.close();
						 JOptionPane.showMessageDialog(null,"ɾ��ѧ��Ϊ��"+ID);
						
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
			}
			
		});
		
	}
	
}
